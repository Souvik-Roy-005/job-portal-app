import React, { useState, useMemo } from 'react';
import {  Search,  MapPin, Briefcase,  Users,  GraduationCap,  DollarSign,  User,  FileText,
    ExternalLink,  ChevronDown,  ChevronUp,  Star,  Clock,  Building,  Target, Award, TrendingUp
} from 'lucide-react';

interface Job {
  id: number;
  jobName: string;
  positionName: string;
  functionalArea: string;
  functionalRole: string;
  avgExperience: string;
  avgWage: string;
  gender: string;
  highestQualification: string;
  state: string;
  district: string;
  description: string;
  requiredSkills: string[];
  company: string;
  jobType: string;
  postedDate: string;
}

const mockJobs: Job[] = [
  {
    id: 1,
    jobName: "Senior Software Developer",
    positionName: "Software Engineer III",
    functionalArea: "Information Technology",
    functionalRole: "Software Development",
    avgExperience: "5-8 years",
    avgWage: "₹12-18 LPA",
    gender: "Any",
    highestQualification: "B.Tech/M.Tech",
    state: "Karnataka",
    district: "Bangalore",
    description: "We are looking for an experienced software developer to join our dynamic team. The role involves developing scalable web applications, working with modern frameworks, and collaborating with cross-functional teams to deliver high-quality software solutions. You'll be responsible for architecting robust systems, mentoring junior developers, and staying up-to-date with the latest technology trends. This is an excellent opportunity to work on cutting-edge projects and grow your career in a fast-paced environment.",
    requiredSkills: ["React", "Node.js", "JavaScript", "TypeScript", "MongoDB", "AWS", "Docker"],
    company: "TechCorp Solutions",
    jobType: "Full-time",
    postedDate: "2024-08-05"
  },
  {
    id: 2,
    jobName: "Data Scientist",
    positionName: "Data Scientist II",
    functionalArea: "Analytics & Data Science",
    functionalRole: "Data Analysis",
    avgExperience: "3-6 years",
    avgWage: "₹10-15 LPA",
    gender: "Any",
    highestQualification: "M.Sc/M.Tech",
    state: "Maharashtra",
    district: "Pune",
    description: "Join our data science team to work on cutting-edge machine learning projects. You'll be responsible for analyzing large datasets, building predictive models, and providing actionable insights to drive business decisions. The role involves working with stakeholders to understand business requirements, developing data pipelines, and presenting findings to executive leadership. Experience with cloud platforms and MLOps practices is highly valued.",
    requiredSkills: ["Python", "Machine Learning", "SQL", "TensorFlow", "Statistics", "Pandas", "Scikit-learn"],
    company: "DataInsights Inc",
    jobType: "Full-time",
    postedDate: "2024-08-04"
  },
  {
    id: 3,
    jobName: "Digital Marketing Manager",
    positionName: "Marketing Manager",
    functionalArea: "Marketing & Communications",
    functionalRole: "Digital Marketing",
    avgExperience: "4-7 years",
    avgWage: "₹8-12 LPA",
    gender: "Any",
    highestQualification: "MBA/BBA",
    state: "Delhi",
    district: "New Delhi",
    description: "Lead our digital marketing initiatives and drive brand growth through innovative campaigns. Manage social media presence, SEO/SEM strategies, and collaborate with creative teams to enhance our online visibility. You'll be responsible for developing comprehensive marketing strategies, analyzing campaign performance, and optimizing ROI across all digital channels. The role requires strong analytical skills and creative thinking.",
    requiredSkills: ["SEO", "Social Media", "Google Ads", "Content Marketing", "Analytics", "Facebook Ads", "Email Marketing"],
    company: "BrandBoost Agency",
    jobType: "Full-time",
    postedDate: "2024-08-03"
  },
  {
    id: 4,
    jobName: "UI/UX Designer",
    positionName: "Senior Designer",
    functionalArea: "Design & Creative",
    functionalRole: "User Experience Design",
    avgExperience: "3-5 years",
    avgWage: "₹6-10 LPA",
    gender: "Any",
    highestQualification: "B.Des/M.Des",
    state: "Karnataka",
    district: "Bangalore",
    description: "Create exceptional user experiences through innovative design solutions. Work closely with product teams to design intuitive interfaces and conduct user research to improve product usability. You'll be involved in the entire design process from wireframing to prototyping, user testing, and final implementation. The role requires a strong portfolio demonstrating expertise in both UI and UX design principles.",
    requiredSkills: ["Figma", "Adobe XD", "Sketch", "Prototyping", "User Research", "Wireframing", "Design Systems"],
    company: "DesignStudio Pro",
    jobType: "Full-time",
    postedDate: "2024-08-02"
  },
  {
    id: 5,
    jobName: "Business Analyst",
    positionName: "Senior Business Analyst",
    functionalArea: "Business Operations",
    functionalRole: "Business Analysis",
    avgExperience: "4-6 years",
    avgWage: "₹7-11 LPA",
    gender: "Any",
    highestQualification: "MBA/BCA",
    state: "Tamil Nadu",
    district: "Chennai",
    description: "Analyze business processes and requirements to identify opportunities for improvement. Work with stakeholders to gather requirements and translate them into technical specifications. You'll be responsible for process mapping, gap analysis, and facilitating communication between business and technical teams. Strong analytical and communication skills are essential for success in this role.",
    requiredSkills: ["SQL", "Excel", "Business Intelligence", "JIRA", "Process Mapping", "Tableau", "Power BI"],
    company: "Business Solutions Ltd",
    jobType: "Full-time",
    postedDate: "2024-08-01"
  },
  {
    id: 6,
    jobName: "Frontend Developer",
    positionName: "Frontend Engineer",
    functionalArea: "Information Technology",
    functionalRole: "Frontend Development",
    avgExperience: "2-4 years",
    avgWage: "₹6-10 LPA",
    gender: "Any",
    highestQualification: "B.Tech/BCA",
    state: "Haryana",
    district: "Gurgaon",
    description: "Build responsive and interactive web applications using modern frontend technologies. Collaborate with designers and backend developers to create seamless user experiences. The role involves optimizing applications for maximum speed and scalability while ensuring cross-browser compatibility.",
    requiredSkills: ["React", "JavaScript", "HTML", "CSS", "Redux", "Webpack", "Git"],
    company: "WebTech Innovations",
    jobType: "Full-time",
    postedDate: "2024-07-30"
  }
];

const JobSearchPortal: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedJobs, setExpandedJobs] = useState<Set<number>>(new Set());

  const calculateMatchScore = (job: Job, query: string): number => {
    if (!query.trim()) return 0; // No score when no search

    const queryLower = query.toLowerCase();
    const searchTerms = queryLower.split(/\s+|,/).filter(term => term.length > 2);

    let score = 0;
    let totalMatches = 0;
    let possibleMatches = 0;

    // Primary skill matching (most important)
    possibleMatches += searchTerms.length;
    searchTerms.forEach(term => {
      const skillMatch = job.requiredSkills.some(skill =>
        skill.toLowerCase().includes(term) || term.includes(skill.toLowerCase())
      );
      if (skillMatch) {
        totalMatches += 1;
        score += 20; // Higher weight for skill matches
      }

      // Also check job title and role for relevance
      const roleMatch = job.jobName.toLowerCase().includes(term) ||
        job.functionalRole.toLowerCase().includes(term) ||
        job.functionalArea.toLowerCase().includes(term);
      if (roleMatch) {
        score += 10;
      }
    });

    // Bonus for multiple skill matches
    const skillMatchCount = job.requiredSkills.filter(skill =>
      searchTerms.some(term =>
        skill.toLowerCase().includes(term) || term.includes(skill.toLowerCase())
      )
    ).length;

    if (skillMatchCount > 1) {
      score += skillMatchCount * 5; // Bonus for multiple matches
    }

    // Calculate final percentage
    const maxPossibleScore = Math.max(searchTerms.length * 25, 50);
    const finalScore = Math.min(Math.round((score / maxPossibleScore) * 100), 95);

    return finalScore;
  };

  const filteredAndScoredJobs = useMemo(() => {
    if (!searchQuery.trim()) {
      return []; // Show no jobs when no search query
    }

    return mockJobs
      .map(job => ({
        ...job,
        matchScore: calculateMatchScore(job, searchQuery)
      }))
      .filter(job => job.matchScore > 15) // Only show jobs with meaningful match
      .sort((a, b) => b.matchScore - a.matchScore);
  }, [searchQuery]);

  const handleApplyJob = (job: Job) => {
    alert(`Applied for ${job.jobName} at ${job.company}! You will be redirected to the application page.`);
  };

  const toggleJobExpansion = (jobId: number) => {
    const newExpanded = new Set(expandedJobs);
    if (newExpanded.has(jobId)) {
      newExpanded.delete(jobId);
    } else {
      newExpanded.add(jobId);
    }
    setExpandedJobs(newExpanded);
  };

  const getMatchScoreColor = (score: number): string => {
    if (score >= 80) return 'text-emerald-700 bg-emerald-50 border-emerald-200';
    if (score >= 60) return 'text-amber-700 bg-amber-50 border-amber-200';
    if (score >= 40) return 'text-blue-700 bg-blue-50 border-blue-200';
    return 'text-slate-700 bg-slate-50 border-slate-200';
  };

  const getMatchScoreBadgeColor = (score: number): string => {
    if (score >= 80) return 'bg-gradient-to-r from-emerald-500 to-teal-500';
    if (score >= 60) return 'bg-gradient-to-r from-amber-500 to-orange-500';
    if (score >= 40) return 'bg-gradient-to-r from-blue-500 to-indigo-500';
    return 'bg-gradient-to-r from-slate-500 to-gray-500';
  };

  const getMatchScoreIcon = (score: number) => {
    if (score >= 80) return <Award className="h-4 w-4" />;
    if (score >= 60) return <Star className="h-4 w-4" />;
    if (score >= 40) return <Target className="h-4 w-4" />;
    return <TrendingUp className="h-4 w-4" />;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md shadow-lg border-b border-white/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-3 rounded-xl shadow-lg">
                <Briefcase className="h-8 w-8 text-white" />
              </div>
              <div className="ml-4">
                <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  JobMatch Pro
                </h1>
                <p className="text-slate-600 text-sm">AI-Powered Career Discovery</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-6 text-sm text-slate-600">
              <div className="flex items-center space-x-2">
                <TrendingUp className="h-4 w-4 text-indigo-500" />
                <span>Smart Matching</span>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="h-4 w-4 text-amber-500" />
                <span>Top Companies</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Search Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600"></div>
        <div className="relative py-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Discover Your Dream Job
              </h2>
              <p className="text-xl text-indigo-100 mb-2">
                Enter your skills and let AI find the perfect matches
              </p>
              <p className="text-indigo-200">
                Our intelligent system analyzes your skills and recommends the best opportunities
              </p>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-white/20 rounded-2xl blur-xl"></div>
              <div className="relative bg-white/90 backdrop-blur-md rounded-2xl p-2 shadow-2xl">
                <div className="flex items-center">
                  <Search className="ml-4 h-6 w-6 text-indigo-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter your skills (e.g., React, Python, JavaScript, SEO, Figma...)"
                    className="flex-1 px-4 py-4 text-lg bg-transparent border-0 focus:ring-0 focus:outline-none placeholder-slate-500"
                  />
                  {searchQuery && (
                    <div className="mr-2">
                      <div className="bg-indigo-100 text-indigo-700 px-4 py-2 rounded-lg text-sm font-medium">
                        {filteredAndScoredJobs.length} matches found
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="mt-8 text-center">
              <p className="text-indigo-100 text-sm mb-4">Popular Skills:</p>
              <div className="flex flex-wrap justify-center gap-2">
                {['React', 'Python', 'JavaScript', 'Node.js', 'AWS', 'Machine Learning', 'Figma', 'SEO'].map((skill) => (
                  <button
                    key={skill}
                    onClick={() => setSearchQuery(skill)}
                    className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full text-sm transition-all duration-200 hover:scale-105"
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {searchQuery && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">
                  Recommended Jobs
                </h3>
                <p className="text-slate-600">
                  {filteredAndScoredJobs.length} jobs matching "{searchQuery}"
                </p>
              </div>
              {filteredAndScoredJobs.length > 0 && (
                <div className="flex items-center space-x-2 text-sm text-slate-500">
                  <Star className="h-4 w-4" />
                  <span>Sorted by match score</span>
                </div>
              )}
            </div>
          </div>
        )}

        {!searchQuery && (
          <div className="text-center py-20">
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-12 max-w-2xl mx-auto">
              <div className="bg-gradient-to-r from-indigo-500 to-purple-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">Start Your Job Search</h3>
              <p className="text-slate-600 text-lg">
                Enter your skills in the search bar above to discover personalized job recommendations powered by AI matching.
              </p>
            </div>
          </div>
        )}

        <div className="space-y-6">
          {filteredAndScoredJobs.map((job) => (
            <div key={job.id} className="bg-white/80 backdrop-blur-md rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden border border-white/20">
              {/* Job Header */}
              <div className="p-8">
                <div className="flex items-start justify-between mb-6">
                  <div className="flex-1">
                    <div className="flex items-start gap-4 mb-4">
                      <div className="bg-gradient-to-r from-slate-100 to-slate-200 p-4 rounded-xl">
                        <Building className="h-8 w-8 text-slate-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="text-2xl font-bold text-slate-900">{job.jobName}</h4>
                          <span className={`px-4 py-2 rounded-full text-sm font-semibold border ${getMatchScoreColor(job.matchScore)}`}>
                            <div className="flex items-center gap-2">
                              {getMatchScoreIcon(job.matchScore)}
                              {job.matchScore}% Match
                            </div>
                          </span>
                        </div>
                        <p className="text-lg font-medium text-slate-700 mb-1">{job.company}</p>
                        <p className="text-slate-600">{job.positionName} • {job.jobType}</p>
                      </div>
                    </div>
                  </div>
                  <div className={`w-20 h-20 rounded-2xl ${getMatchScoreBadgeColor(job.matchScore)} flex items-center justify-center text-white shadow-lg`}>
                    <div className="text-center">
                      <div className="text-xl font-bold">{job.matchScore}%</div>
                      <div className="text-xs opacity-90">MATCH</div>
                    </div>
                  </div>
                </div>

                {/* Quick Info Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                  <div className="flex items-center gap-3 p-4 bg-slate-50/80 rounded-xl">
                    <MapPin className="h-5 w-5 text-indigo-500" />
                    <div>
                      <div className="text-sm text-slate-500">Location</div>
                      <div className="font-semibold text-slate-700">{job.district}, {job.state}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-slate-50/80 rounded-xl">
                    <Clock className="h-5 w-5 text-emerald-500" />
                    <div>
                      <div className="text-sm text-slate-500">Experience</div>
                      <div className="font-semibold text-slate-700">{job.avgExperience}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-slate-50/80 rounded-xl">
                    <DollarSign className="h-5 w-5 text-amber-500" />
                    <div>
                      <div className="text-sm text-slate-500">Salary</div>
                      <div className="font-semibold text-slate-700">{job.avgWage}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-slate-50/80 rounded-xl">
                    <GraduationCap className="h-5 w-5 text-purple-500" />
                    <div>
                      <div className="text-sm text-slate-500">Education</div>
                      <div className="font-semibold text-slate-700">{job.highestQualification}</div>
                    </div>
                  </div>
                </div>

                {/* Skills Tags */}
                <div className="mb-6">
                  <h5 className="text-sm font-semibold text-slate-600 mb-3">Required Skills</h5>
                  <div className="flex flex-wrap gap-2">
                    {job.requiredSkills.map((skill, index) => {
                      const isMatched = searchQuery.toLowerCase().split(/\s+|,/).some(term =>
                        skill.toLowerCase().includes(term) || term.includes(skill.toLowerCase())
                      );
                      return (
                        <span
                          key={index}
                          className={`px-4 py-2 rounded-full text-sm font-medium border ${isMatched
                              ? 'bg-gradient-to-r from-indigo-100 to-purple-100 text-indigo-700 border-indigo-200'
                              : 'bg-slate-100 text-slate-700 border-slate-200'
                            }`}
                        >
                          {skill}
                          {isMatched && <Star className="inline h-3 w-3 ml-1" />}
                        </span>
                      );
                    })}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between">
                  <button
                    onClick={() => toggleJobExpansion(job.id)}
                    className="flex items-center gap-2 text-indigo-600 hover:text-indigo-800 font-medium transition-colors duration-200"
                  >
                    <FileText className="h-4 w-4" />
                    {expandedJobs.has(job.id) ? 'Hide Details' : 'View Details'}
                    {expandedJobs.has(job.id) ?
                      <ChevronUp className="h-4 w-4" /> :
                      <ChevronDown className="h-4 w-4" />
                    }
                  </button>
                  <div className="flex gap-3">
                    <button className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-6 py-3 rounded-xl font-medium transition-all duration-200 hover:scale-105">
                      Save Job
                    </button>
                    <button
                      onClick={() => handleApplyJob(job)}
                      className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-medium transition-all duration-200 hover:scale-105 flex items-center gap-2 shadow-lg"
                    >
                      <ExternalLink className="h-4 w-4" />
                      Apply Now
                    </button>
                  </div>
                </div>
              </div>

              {/* Collapsible Details */}
              {expandedJobs.has(job.id) && (
                <div className="border-t border-slate-200 bg-slate-50/80 backdrop-blur-sm">
                  <div className="p-8">
                    <div className="grid md:grid-cols-2 gap-8 mb-8">
                      <div className="space-y-6">
                        <div className="bg-white/60 p-6 rounded-xl">
                          <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                            <Briefcase className="h-5 w-5 text-indigo-500" />
                            Position Details
                          </h4>
                          <div className="space-y-3 text-sm">
                            <div className="flex justify-between">
                              <span className="text-slate-600">Functional Area:</span>
                              <span className="font-medium text-slate-900">{job.functionalArea}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-600">Functional Role:</span>
                              <span className="font-medium text-slate-900">{job.functionalRole}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-600">Posted Date:</span>
                              <span className="font-medium text-slate-900">{job.postedDate}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-slate-600">Gender Requirement:</span>
                              <span className="font-medium text-slate-900">{job.gender}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="bg-white/60 p-6 rounded-xl">
                          <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                            <Target className="h-5 w-5 text-emerald-500" />
                            Match Analysis
                          </h4>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-slate-600 text-sm">Overall Match</span>
                              <div className="flex items-center gap-2">
                                <div className="w-24 bg-slate-200 rounded-full h-2">
                                  <div
                                    className={`h-2 rounded-full ${job.matchScore >= 80 ? 'bg-gradient-to-r from-emerald-500 to-teal-500' : job.matchScore >= 60 ? 'bg-gradient-to-r from-amber-500 to-orange-500' : 'bg-gradient-to-r from-blue-500 to-indigo-500'}`}
                                    style={{ width: `${job.matchScore}%` }}
                                  ></div>
                                </div>
                                <span className="font-bold text-slate-900">{job.matchScore}%</span>
                              </div>
                            </div>
                            <div className="text-xs text-slate-500">
                              Based on skills, experience, and role relevance
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-white/60 p-6 rounded-xl mb-6">
                      <h4 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                        <FileText className="h-5 w-5 text-purple-500" />
                        Job Description
                      </h4>
                      <p className="text-slate-700 leading-relaxed">{job.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-6 border-t border-slate-200">
                      <div className={`px-6 py-3 rounded-xl border ${getMatchScoreColor(job.matchScore)}`}>
                        <div className="flex items-center gap-2">
                          {getMatchScoreIcon(job.matchScore)}
                          <span className="font-bold">Match Score: {job.matchScore}%</span>
                        </div>
                      </div>
                      <div className="flex gap-3">
                        <button
                          onClick={() => toggleJobExpansion(job.id)}
                          className="px-6 py-3 border border-slate-300 text-slate-700 rounded-xl hover:bg-slate-50 transition-colors duration-200"
                        >
                          Collapse Details
                        </button>
                        <button
                          onClick={() => handleApplyJob(job)}
                          className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl font-medium flex items-center gap-2 transition-all duration-200 hover:scale-105 shadow-lg"
                        >
                          <ExternalLink className="h-4 w-4" />
                          Apply for This Job
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {filteredAndScoredJobs.length === 0 && searchQuery && (
          <div className="text-center py-16">
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-12 max-w-2xl mx-auto">
              <div className="bg-gradient-to-r from-slate-400 to-slate-500 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">No Jobs Found</h3>
              <p className="text-slate-600 text-lg mb-6">
                We couldn't find any jobs matching "{searchQuery}". Try adjusting your search terms or explore different skills.
              </p>
              <div className="space-y-4">
                <p className="text-sm text-slate-500 mb-4">Try searching for:</p>
                <div className="flex flex-wrap justify-center gap-2">
                  {['Frontend Development', 'Backend Development', 'Data Science', 'Digital Marketing', 'UI/UX Design'].map((suggestion) => (
                    <button
                      key={suggestion}
                      onClick={() => setSearchQuery(suggestion)}
                      className="bg-gradient-to-r from-indigo-100 to-purple-100 hover:from-indigo-200 hover:to-purple-200 text-indigo-700 px-4 py-2 rounded-full text-sm transition-all duration-200 hover:scale-105"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default JobSearchPortal;